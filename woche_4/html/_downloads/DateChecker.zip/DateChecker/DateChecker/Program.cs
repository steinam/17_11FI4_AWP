﻿namespace DateChecker
{
    class Program
    {
        static void Main(string[] args)
        {

            //int result = KalendarRoutines.Calendar.week_day(1, 1, 2017);


        }
    }
}
